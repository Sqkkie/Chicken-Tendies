# Chicken Tendies (Dopamine, rootless)

Imports .tendies wallpaper packages into PosterBoard. Configure everything in Settings > Chicken Tendies.

Targets: iOS 16.3.1 and 16.7.4 on Dopamine, arm64 and arm64e (fat binary).

## Build (Theos + iOS 16 SDK)
    make package

Rootless scheme and both architectures are set in the Makefile.
Needs on-device: preferenceloader, unzip, shell-cmds (killall).

## How it works
Settings bundle -> prefs + Darwin notification -> SpringBoard-side tweak unzips the .tendies,
merges it into /var/mobile/Library/Application Support/PRBPosterExtensionDataStore/<N>/Extensions/...,
then restarts PosterBoard. Backups: /var/mobile/Library/ChickenTendies/Backups.

## Building from an iPhone (no PC)
See the chat instructions: upload ChickenTendies.zip as-is to a GitHub repo,
then create `.github/workflows/build.yml` with GitHub's "Create new file" and
paste the contents of build.yml.txt. The workflow unzips the project itself.
