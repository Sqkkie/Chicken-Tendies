#import "CTImporter.h"
#import <spawn.h>
#import <sys/wait.h>
#import <notify.h>
#if __has_include(<rootless.h>)
#import <rootless.h>
#endif
#ifndef ROOT_PATH_NS
#define ROOT_PATH_NS(p) p
#endif

extern char **environ;

NSString *const CTDomain = @"com.chickentendies.prefs";
static NSString *const kStoreRoot = @"/var/mobile/Library/Application Support/PRBPosterExtensionDataStore";
static NSString *const kWork      = @"/var/mobile/Library/ChickenTendies";
static NSString *const kDefInbox  = @"/var/mobile/Documents/ChickenTendies";
static NSString *const kDefExt    = @"com.apple.WallpaperKit.CollectionsPoster";

#pragma mark - helpers

static id CTGet(NSString *k, id def) {
    CFPreferencesAppSynchronize((__bridge CFStringRef)CTDomain);
    CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)k, (__bridge CFStringRef)CTDomain);
    return v ? CFBridgingRelease(v) : def;
}
static BOOL CTBool(NSString *k, BOOL def) {
    id v = CTGet(k, @(def));
    return [v respondsToSelector:@selector(boolValue)] ? [v boolValue] : def;
}
static void CTSet(NSString *k, id v) {
    CFPreferencesSetAppValue((__bridge CFStringRef)k, (__bridge CFPropertyListRef)v, (__bridge CFStringRef)CTDomain);
    CFPreferencesAppSynchronize((__bridge CFStringRef)CTDomain);
}
static void CTStatus(NSString *msg) {
    NSDateFormatter *f = [NSDateFormatter new];
    f.dateFormat = @"HH:mm:ss";
    CTSet(@"status", [NSString stringWithFormat:@"[%@] %@", [f stringFromDate:[NSDate date]], msg]);
    notify_post("com.chickentendies/statusChanged");
}
static int CTRun(NSString *tool, NSArray<NSString *> *args) {
    NSMutableArray *a = [NSMutableArray arrayWithObject:tool.lastPathComponent];
    [a addObjectsFromArray:args];
    char *argv[a.count + 1];
    for (NSUInteger i = 0; i < a.count; i++) argv[i] = (char *)[a[i] UTF8String];
    argv[a.count] = NULL;
    pid_t pid;
    if (posix_spawn(&pid, tool.fileSystemRepresentation, NULL, NULL, argv, environ) != 0) return -1;
    int st = 0;
    waitpid(pid, &st, 0);
    return WIFEXITED(st) ? WEXITSTATUS(st) : -1;
}
static NSString *CTInbox(void) {
    NSString *p = CTGet(@"inboxPath", kDefInbox);
    return p.length ? p : kDefInbox;
}
static NSString *CTSignature(NSString *path) {
    NSDictionary *a = [[NSFileManager defaultManager] attributesOfItemAtPath:path error:nil];
    return [NSString stringWithFormat:@"%@|%@|%@", path.lastPathComponent, a[NSFileSize], a[NSFileModificationDate]];
}

#pragma mark - importer

@implementation CTImporter {
    NSFileManager *_fm;
    NSInteger _scanned;
    NSString *_scanError;
}

+ (instancetype)shared {
    static CTImporter *i; static dispatch_once_t t;
    dispatch_once(&t, ^{ i = [CTImporter new]; i->_fm = [NSFileManager defaultManager]; });
    return i;
}

- (BOOL)enabledOrStatus {
    if (CTBool(@"enabled", YES)) return YES;
    CTStatus(@"Tweak is disabled in settings.");
    return NO;
}

// Returns the newest ".../<store>/<N>/Extensions" (or ".../<store>/Extensions") inside one PRBPosterExtensionDataStore folder.
- (NSString *)extensionsInStore:(NSString *)store {
    BOOL d;
    NSString *direct = [store stringByAppendingPathComponent:@"Extensions"];
    if ([_fm fileExistsAtPath:direct isDirectory:&d] && d) return direct;
    NSArray *items = [_fm contentsOfDirectoryAtPath:store error:nil];
    items = [items sortedArrayUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
        return [@(b.integerValue) compare:@(a.integerValue)];
    }];
    for (NSString *i in items) {
        NSString *e = [[store stringByAppendingPathComponent:i] stringByAppendingPathComponent:@"Extensions"];
        if ([_fm fileExistsAtPath:e isDirectory:&d] && d) return e;
    }
    return nil;
}

// On iOS 16 PosterBoard is a PluginKit app extension, so its data store is inside
// /var/mobile/Containers/Data/PluginKitPlugin/<UUID>/Library/Application Support/PRBPosterExtensionDataStore
- (NSString *)extensionsDir {
    NSMutableArray *stores = [NSMutableArray arrayWithObject:kStoreRoot];
    NSString *plug = @"/var/mobile/Containers/Data/PluginKitPlugin";
    NSError *listErr = nil;
    NSArray *uuids = [_fm contentsOfDirectoryAtPath:plug error:&listErr];
    _scanned = (NSInteger)uuids.count;
    _scanError = listErr.localizedDescription;
    for (NSString *u in uuids) {
        NSString *s = [plug stringByAppendingPathComponent:
            [u stringByAppendingPathComponent:@"Library/Application Support/PRBPosterExtensionDataStore"]];
        if ([_fm fileExistsAtPath:s]) [stores addObject:s];
    }
    NSString *fallback = nil;
    for (NSString *s in stores) {
        NSString *e = [self extensionsInStore:s];
        if (!e) continue;
        NSString *col = [e stringByAppendingPathComponent:@"com.apple.WallpaperKit.CollectionsPoster"];
        if ([_fm fileExistsAtPath:col]) return e;   // best match: has the Collections extension
        if (!fallback) fallback = e;
    }
    return fallback;
}

- (BOOL)merge:(NSString *)src into:(NSString *)dst error:(NSError **)err {
    BOOL isDir;
    if (![_fm fileExistsAtPath:src isDirectory:&isDir]) return NO;
    if (!isDir) {
        [_fm createDirectoryAtPath:dst.stringByDeletingLastPathComponent withIntermediateDirectories:YES attributes:nil error:nil];
        [_fm removeItemAtPath:dst error:nil];
        return [_fm copyItemAtPath:src toPath:dst error:err];
    }
    if (![_fm createDirectoryAtPath:dst withIntermediateDirectories:YES attributes:nil error:err]) return NO;
    for (NSString *c in [_fm contentsOfDirectoryAtPath:src error:nil]) {
        if ([c isEqualToString:@".DS_Store"]) continue;
        if (![self merge:[src stringByAppendingPathComponent:c] into:[dst stringByAppendingPathComponent:c] error:err]) return NO;
    }
    return YES;
}

- (NSArray<NSString *> *)find:(BOOL (^)(NSString *name, NSString *path))pred under:(NSString *)root maxDepth:(NSUInteger)depth {
    NSMutableArray *out = [NSMutableArray array];
    NSDirectoryEnumerator *en = [_fm enumeratorAtPath:root];
    for (NSString *rel in en) {
        if ([rel.lastPathComponent isEqualToString:@"__MACOSX"]) { [en skipDescendants]; continue; }
        NSString *full = [root stringByAppendingPathComponent:rel];
        BOOL d;
        if (![_fm fileExistsAtPath:full isDirectory:&d] || !d) continue;
        if (pred(rel.lastPathComponent, full)) { [out addObject:full]; [en skipDescendants]; continue; }
        if (en.level >= depth) [en skipDescendants];
    }
    return out;
}

// Works out which folders in the unzipped .tendies go where in the data store.
- (NSArray<NSDictionary *> *)planFor:(NSString *)tmp extensions:(NSString *)extDir {
    NSString *target = CTGet(@"targetExtension", kDefExt);
    NSArray *hits;

    // 1) archive carries a full "Extensions" tree
    hits = [self find:^BOOL(NSString *n, NSString *p) { return [n isEqualToString:@"Extensions"]; } under:tmp maxDepth:4];
    if (hits.count) {
        NSMutableArray *plan = [NSMutableArray array];
        for (NSString *h in hits)
            for (NSString *c in [_fm contentsOfDirectoryAtPath:h error:nil])
                if (![c isEqualToString:@".DS_Store"]) [plan addObject:@{@"src": [h stringByAppendingPathComponent:c], @"dst": c}];
        return plan;
    }
    // 2) archive carries extension folders (com.apple.xxx/descriptors/...)
    hits = [self find:^BOOL(NSString *n, NSString *p) { return [n hasPrefix:@"com.apple."]; } under:tmp maxDepth:4];
    if (hits.count) {
        NSMutableArray *plan = [NSMutableArray array];
        for (NSString *h in hits) [plan addObject:@{@"src": h, @"dst": h.lastPathComponent}];
        return plan;
    }
    // 3) archive carries a "descriptors" folder
    hits = [self find:^BOOL(NSString *n, NSString *p) { return [n isEqualToString:@"descriptors"]; } under:tmp maxDepth:4];
    if (hits.count) {
        NSMutableArray *plan = [NSMutableArray array];
        for (NSString *h in hits)
            for (NSString *c in [_fm contentsOfDirectoryAtPath:h error:nil])
                if (![c isEqualToString:@".DS_Store"]) [plan addObject:@{@"src": [h stringByAppendingPathComponent:c],
                                  @"dst": [NSString stringWithFormat:@"%@/descriptors/%@", target, c]}];
        return plan;
    }
    // 4) bare descriptor folders (contain "versions")
    hits = [self find:^BOOL(NSString *n, NSString *p) {
        BOOL d; return [[NSFileManager defaultManager] fileExistsAtPath:[p stringByAppendingPathComponent:@"versions"] isDirectory:&d] && d;
    } under:tmp maxDepth:4];
    NSMutableArray *plan = [NSMutableArray array];
    for (NSString *h in hits)
        [plan addObject:@{@"src": h, @"dst": [NSString stringWithFormat:@"%@/descriptors/%@", target, h.lastPathComponent]}];
    return plan;
}

- (NSString *)newBackupDir {
    NSDateFormatter *f = [NSDateFormatter new];
    f.dateFormat = @"yyyyMMdd-HHmmss";
    NSString *d = [[kWork stringByAppendingPathComponent:@"Backups"] stringByAppendingPathComponent:[f stringFromDate:[NSDate date]]];
    [_fm createDirectoryAtPath:[d stringByAppendingPathComponent:@"data"] withIntermediateDirectories:YES attributes:nil error:nil];
    return d;
}

// returns nil on success, otherwise an error string
- (NSString *)importOne:(NSString *)path extensions:(NSString *)extDir backup:(NSString *)backupDir
               restore:(NSMutableArray *)restoreList remove:(NSMutableArray *)removeList {
    if (![path.pathExtension.lowercaseString isEqualToString:@"tendies"]) return @"not a .tendies file";
    if (![_fm fileExistsAtPath:path]) return @"file not found";

    NSString *tmp = [[kWork stringByAppendingPathComponent:@"tmp"] stringByAppendingPathComponent:[[NSUUID UUID] UUIDString]];
    [_fm createDirectoryAtPath:tmp withIntermediateDirectories:YES attributes:nil error:nil];

    NSString *result = nil;
    if (CTRun(ROOT_PATH_NS(@"/usr/bin/unzip"), @[@"-o", @"-q", path, @"-d", tmp]) != 0) {
        result = @"unzip failed (is the file a valid .tendies?)";
    } else {
        NSArray *plan = [self planFor:tmp extensions:extDir];
        if (!plan.count) {
            result = @"no wallpaper descriptors found inside archive";
        } else {
            for (NSDictionary *item in plan) {
                NSString *rel = item[@"dst"];
                NSString *dst = [extDir stringByAppendingPathComponent:rel];
                if (backupDir) {
                    if ([_fm fileExistsAtPath:dst]) {
                        if (![restoreList containsObject:rel]) {
                            NSString *b = [[backupDir stringByAppendingPathComponent:@"data"] stringByAppendingPathComponent:rel];
                            [_fm createDirectoryAtPath:b.stringByDeletingLastPathComponent withIntermediateDirectories:YES attributes:nil error:nil];
                            [_fm copyItemAtPath:dst toPath:b error:nil];
                            [restoreList addObject:rel];
                        }
                    } else if (![removeList containsObject:rel]) {
                        [removeList addObject:rel];
                    }
                }
                NSError *e = nil;
                if (![self merge:item[@"src"] into:dst error:&e]) { result = e.localizedDescription ?: @"copy failed"; break; }
            }
        }
    }
    [_fm removeItemAtPath:tmp error:nil];
    return result;
}

- (void)importPaths:(NSArray<NSString *> *)paths auto:(BOOL)auto_ {
    if (![self enabledOrStatus]) return;
    if (!paths.count) { CTStatus(@"Nothing to import."); return; }

    NSString *ext = [self extensionsDir];
    if (!ext) {
        CTStatus([NSString stringWithFormat:@"PosterBoard data store not found (checked %ld plugin containers%@). Open the Lock Screen editor once, then retry.",
                  (long)_scanned, _scanError ? [@"; " stringByAppendingString:_scanError] : @""]);
        return;
    }

    BOOL backup = CTBool(@"backup", YES);
    NSString *bdir = backup ? [self newBackupDir] : nil;
    NSMutableArray *restoreList = [NSMutableArray array], *removeList = [NSMutableArray array];
    NSMutableArray *errors = [NSMutableArray array];
    NSMutableArray *done = [NSMutableArray array];
    NSMutableArray *imported = [NSMutableArray arrayWithArray:CTGet(@"imported", @[])];

    for (NSString *p in paths) {
        NSString *err = [self importOne:p extensions:ext backup:bdir restore:restoreList remove:removeList];
        if (err) { [errors addObject:[NSString stringWithFormat:@"%@: %@", p.lastPathComponent, err]]; continue; }
        [done addObject:p];
        [imported addObject:CTSignature(p)];
        if (CTBool(@"deleteAfter", NO)) [_fm removeItemAtPath:p error:nil];
    }
    CTSet(@"imported", imported);

    if (bdir) {
        if (restoreList.count || removeList.count)
            [@{@"restore": restoreList, @"remove": removeList} writeToFile:[bdir stringByAppendingPathComponent:@"manifest.plist"] atomically:YES];
        else [_fm removeItemAtPath:bdir error:nil];
    }

    if (done.count && CTBool(@"restartPoster", YES)) [self restartPosterBoard];

    NSString *msg = [NSString stringWithFormat:@"Imported %lu of %lu.", (unsigned long)done.count, (unsigned long)paths.count];
    if (errors.count) msg = [msg stringByAppendingFormat:@" Errors: %@", [errors componentsJoinedByString:@"; "]];
    CTStatus(msg);
    [self scanInbox];
}

- (void)importPending {
    NSArray *p = CTGet(@"pending", @[]);
    CTSet(@"pending", @[]);
    [self importPaths:p auto:NO];
}

- (NSArray<NSString *> *)inboxFiles {
    NSString *dir = CTInbox();
    [_fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    NSMutableArray *out = [NSMutableArray array];
    for (NSString *n in [[_fm contentsOfDirectoryAtPath:dir error:nil] sortedArrayUsingSelector:@selector(compare:)])
        if ([n.pathExtension.lowercaseString isEqualToString:@"tendies"]) [out addObject:n];
    return out;
}

- (void)scanInbox {
    CTSet(@"inboxDir", CTInbox());
    CTSet(@"inbox", [self inboxFiles]);
    notify_post("com.chickentendies/statusChanged");
}

- (void)importInboxAuto:(BOOL)auto_ {
    if (![self enabledOrStatus]) return;
    NSArray *seen = CTGet(@"imported", @[]);
    NSMutableArray *paths = [NSMutableArray array];
    for (NSString *n in [self inboxFiles]) {
        NSString *p = [CTInbox() stringByAppendingPathComponent:n];
        if (auto_ && [seen containsObject:CTSignature(p)]) continue;
        [paths addObject:p];
    }
    if (auto_ && !paths.count) { [self scanInbox]; return; }
    [self importPaths:paths auto:auto_];
}

- (void)restoreLatestBackup {
    NSString *root = [kWork stringByAppendingPathComponent:@"Backups"];
    NSString *latest = [[[_fm contentsOfDirectoryAtPath:root error:nil] sortedArrayUsingSelector:@selector(compare:)] lastObject];
    NSString *ext = [self extensionsDir];
    if (!latest || !ext) { CTStatus(@"No backup to restore."); return; }
    NSString *b = [root stringByAppendingPathComponent:latest];
    NSDictionary *m = [NSDictionary dictionaryWithContentsOfFile:[b stringByAppendingPathComponent:@"manifest.plist"]];
    if (!m) { CTStatus(@"Latest backup has no manifest."); return; }
    for (NSString *rel in m[@"remove"]) [_fm removeItemAtPath:[ext stringByAppendingPathComponent:rel] error:nil];
    for (NSString *rel in m[@"restore"]) {
        NSString *dst = [ext stringByAppendingPathComponent:rel];
        [_fm removeItemAtPath:dst error:nil];
        [_fm copyItemAtPath:[[b stringByAppendingPathComponent:@"data"] stringByAppendingPathComponent:rel] toPath:dst error:nil];
    }
    [_fm removeItemAtPath:b error:nil];
    [self restartPosterBoard];
    CTStatus([NSString stringWithFormat:@"Restored backup %@.", latest]);
}

- (void)restartPosterBoard {
    CTRun(ROOT_PATH_NS(@"/usr/bin/killall"), @[@"PosterBoard"]);
}
- (void)restartSpringBoard {
    CTRun(ROOT_PATH_NS(@"/usr/bin/killall"), @[@"-9", @"SpringBoard"]);
}
@end
