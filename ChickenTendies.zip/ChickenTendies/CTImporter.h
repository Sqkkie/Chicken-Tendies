#import <Foundation/Foundation.h>

extern NSString *const CTDomain;

@interface CTImporter : NSObject
+ (instancetype)shared;
- (void)scanInbox;
- (void)importPending;
- (void)importInboxAuto:(BOOL)auto_;
- (void)applyQueue;
- (void)restoreLatestBackup;
- (void)restartPosterBoard;
- (void)restartSpringBoard;
@end
