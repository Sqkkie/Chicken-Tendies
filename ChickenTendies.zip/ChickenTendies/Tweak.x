// Chicken Tendies - runs inside SpringBoard (unsandboxed enough to write PosterBoard's data store).
// The Settings bundle talks to it with Darwin notifications + the com.chickentendies.prefs domain.
#import <Foundation/Foundation.h>
#import "CTImporter.h"

static dispatch_queue_t gQueue;

static void CTHandler(CFNotificationCenterRef c, void *o, CFStringRef name, const void *obj, CFDictionaryRef ui) {
    NSString *n = (__bridge NSString *)name;
    dispatch_async(gQueue, ^{
        CTImporter *i = [CTImporter shared];
        if      ([n hasSuffix:@"/importPending"])      [i importPending];
        else if ([n hasSuffix:@"/importInbox"])        [i importInboxAuto:NO];
        else if ([n hasSuffix:@"/scan"])               [i scanInbox];
        else if ([n hasSuffix:@"/apply"])              [i applyQueue];
        else if ([n hasSuffix:@"/restore"])            [i restoreLatestBackup];
        else if ([n hasSuffix:@"/restartPoster"])      [i restartPosterBoard];
        else if ([n hasSuffix:@"/restartSpringBoard"]) [i restartSpringBoard];
    });
}

%ctor {
    @autoreleasepool {
        gQueue = dispatch_queue_create("com.chickentendies.queue", DISPATCH_QUEUE_SERIAL);
        NSArray *names = @[@"importPending", @"importInbox", @"scan", @"apply", @"restore", @"restartPoster", @"restartSpringBoard"];
        for (NSString *n in names) {
            CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, CTHandler,
                (__bridge CFStringRef)[@"com.chickentendies/" stringByAppendingString:n], NULL,
                CFNotificationSuspensionBehaviorDeliverImmediately);
        }
        // Auto-import anything new in the inbox folder shortly after respring
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 20 * NSEC_PER_SEC), gQueue, ^{
            CFPreferencesAppSynchronize((__bridge CFStringRef)CTDomain);
            [[CTImporter shared] scanInbox];
            CFPropertyListRef a = CFPreferencesCopyAppValue(CFSTR("autoImport"), (__bridge CFStringRef)CTDomain);
            id v = a ? CFBridgingRelease(a) : nil;
            if ([v respondsToSelector:@selector(boolValue)] && [v boolValue])
                [[CTImporter shared] importInboxAuto:YES];
        });
    }
}
