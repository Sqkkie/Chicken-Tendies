#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import <notify.h>

static NSString *const D = @"com.chickentendies.prefs";
static NSString *const kStatusNote = @"com.chickentendies/statusChanged";

static id CTGet(NSString *k, id def) {
    CFPreferencesAppSynchronize((__bridge CFStringRef)D);
    CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)k, (__bridge CFStringRef)D);
    return v ? CFBridgingRelease(v) : def;
}
static void CTSet(NSString *k, id v) {
    CFPreferencesSetAppValue((__bridge CFStringRef)k, (__bridge CFPropertyListRef)v, (__bridge CFStringRef)D);
    CFPreferencesAppSynchronize((__bridge CFStringRef)D);
}
static void CTPost(NSString *n) { notify_post([[@"com.chickentendies/" stringByAppendingString:n] UTF8String]); }

@interface CTRootListController : PSListController <UIDocumentPickerDelegate>
@end

static void CTStatusCB(CFNotificationCenterRef c, void *obs, CFStringRef n, const void *o, CFDictionaryRef u) {
    CTRootListController *vc = (__bridge CTRootListController *)obs;
    dispatch_async(dispatch_get_main_queue(), ^{ [vc reloadSpecifiers]; });
}

@implementation CTRootListController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), (__bridge const void *)self, CTStatusCB,
        (__bridge CFStringRef)kStatusNote, NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
    CTPost(@"scan");
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    CFNotificationCenterRemoveEveryObserver(CFNotificationCenterGetDarwinNotifyCenter(), (__bridge const void *)self);
}

#pragma mark specifier helpers

- (PSSpecifier *)group:(NSString *)name footer:(NSString *)footer {
    PSSpecifier *g = [PSSpecifier groupSpecifierWithName:name];
    if (footer) [g setProperty:footer forKey:@"footerText"];
    return g;
}
- (PSSpecifier *)toggle:(NSString *)name key:(NSString *)key def:(BOOL)def {
    PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:name target:self
        set:@selector(setPreferenceValue:specifier:) get:@selector(readPreferenceValue:)
        detail:nil cell:PSSwitchCell edit:nil];
    [s setProperty:D forKey:@"defaults"];
    [s setProperty:key forKey:@"key"];
    [s setProperty:@(def) forKey:@"default"];
    return s;
}
- (PSSpecifier *)button:(NSString *)name action:(SEL)sel {
    PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:name target:self set:nil get:nil
        detail:nil cell:PSButtonCell edit:nil];
    s.buttonAction = sel;
    return s;
}

- (NSArray *)specifiers {
    if (_specifiers) return _specifiers;
    NSMutableArray *s = [NSMutableArray array];
    NSString *status = CTGet(@"status", @"Idle.");

    [s addObject:[self group:@"Chicken Tendies" footer:status]];
    [s addObject:[self toggle:@"Enabled" key:@"enabled" def:YES]];

    // Import
    [s addObject:[self group:@"Import" footer:@"Pick .tendies files from the Files app, or drop them into the inbox folder below and tap Import All."]];
    [s addObject:[self button:@"Import .tendies from Files…" action:@selector(pickFiles)]];
    [s addObject:[self button:@"Import All From Inbox" action:@selector(importInbox)]];

    // Inbox contents
    NSArray *files = CTGet(@"inbox", @[]);
    NSString *inboxDir = CTGet(@"inboxDir", @"/var/mobile/Documents/ChickenTendies");
    [s addObject:[self group:@"Inbox" footer:(files.count ? [NSString stringWithFormat:@"Folder: %@", inboxDir]
                                                          : [NSString stringWithFormat:@"No .tendies files in %@", inboxDir])]];
    for (NSString *f in files) {
        PSSpecifier *b = [self button:[@"Import " stringByAppendingString:f] action:@selector(importOne:)];
        [b setProperty:f forKey:@"file"];
        [s addObject:b];
    }
    [s addObject:[self button:@"Refresh Inbox" action:@selector(refreshInbox)]];

    // Options
    [s addObject:[self group:@"Options" footer:nil]];
    [s addObject:[self toggle:@"Restart PosterBoard After Import" key:@"restartPoster" def:YES]];
    [s addObject:[self toggle:@"Back Up Before Importing" key:@"backup" def:YES]];
    [s addObject:[self toggle:@"Delete .tendies After Import" key:@"deleteAfter" def:NO]];
    [s addObject:[self toggle:@"Auto-Import Inbox After Respring" key:@"autoImport" def:NO]];

    PSSpecifier *ext = [PSSpecifier preferenceSpecifierNamed:@"Default Target Extension" target:self
        set:@selector(setPreferenceValue:specifier:) get:@selector(readPreferenceValue:)
        detail:NSClassFromString(@"PSListItemsController") cell:PSLinkListCell edit:nil];
    [ext setProperty:D forKey:@"defaults"];
    [ext setProperty:@"targetExtension" forKey:@"key"];
    [ext setProperty:@"com.apple.WallpaperKit.CollectionsPoster" forKey:@"default"];
    [ext setProperty:@[@"com.apple.WallpaperKit.CollectionsPoster", @"com.apple.PhotosUIPrivate.PhotosPosterProvider"] forKey:@"validValues"];
    [ext setProperty:@[@"Collections", @"Photos"] forKey:@"validTitles"];
    [s addObject:ext];

    PSSpecifier *path = [PSSpecifier preferenceSpecifierNamed:@"Inbox Folder" target:self
        set:@selector(setPreferenceValue:specifier:) get:@selector(readPreferenceValue:)
        detail:nil cell:PSEditTextCell edit:nil];
    [path setProperty:D forKey:@"defaults"];
    [path setProperty:@"inboxPath" forKey:@"key"];
    [path setProperty:@"/var/mobile/Documents/ChickenTendies" forKey:@"default"];
    [path setProperty:@YES forKey:@"noAutoCorrect"];
    [s addObject:path];
    [s addObject:[self group:nil footer:@"Used for 'Import All' and auto-import. Used only as a fallback if a .tendies file doesn't specify an extension."]];

    // Maintenance
    [s addObject:[self group:@"Maintenance" footer:@"Restore undoes the most recent import (needs 'Back Up Before Importing' on)."]];
    [s addObject:[self button:@"Restore Latest Backup" action:@selector(restore)]];
    [s addObject:[self button:@"Restart PosterBoard" action:@selector(restartPoster)]];
    [s addObject:[self button:@"Respring" action:@selector(respring)]];

    _specifiers = s;
    return s;
}

#pragma mark actions

- (void)queue:(NSArray *)paths {
    CTSet(@"pending", paths);
    CTPost(@"importPending");
}
- (void)importOne:(PSSpecifier *)spec {
    NSString *f = [spec propertyForKey:@"file"];
    NSString *dir = CTGet(@"inboxDir", @"/var/mobile/Documents/ChickenTendies");
    [self queue:@[[dir stringByAppendingPathComponent:f]]];
}
- (void)importInbox  { CTPost(@"importInbox"); }
- (void)refreshInbox { CTPost(@"scan"); }
- (void)restartPoster { CTPost(@"restartPoster"); }

- (void)confirm:(NSString *)title msg:(NSString *)msg ok:(void (^)(void))ok {
    UIAlertController *a = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [a addAction:[UIAlertAction actionWithTitle:@"Continue" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *x) { ok(); }]];
    [self presentViewController:a animated:YES completion:nil];
}
- (void)restore { [self confirm:@"Restore latest backup?" msg:@"This reverts the most recent import." ok:^{ CTPost(@"restore"); }]; }
- (void)respring { [self confirm:@"Respring?" msg:nil ok:^{ CTPost(@"restartSpringBoard"); }]; }

- (void)pickFiles {
    UIDocumentPickerViewController *p = [[UIDocumentPickerViewController alloc]
        initForOpeningContentTypes:@[UTTypeItem] asCopy:YES];
    p.allowsMultipleSelection = YES;
    p.delegate = self;
    [self presentViewController:p animated:YES completion:nil];
}
- (void)documentPicker:(UIDocumentPickerViewController *)c didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSMutableArray *paths = [NSMutableArray array];
    for (NSURL *u in urls)
        if ([u.pathExtension.lowercaseString isEqualToString:@"tendies"]) [paths addObject:u.path];
    if (!paths.count) {
        UIAlertController *a = [UIAlertController alertControllerWithTitle:@"No .tendies files"
            message:@"The selected files don't have the .tendies extension." preferredStyle:UIAlertControllerStyleAlert];
        [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:a animated:YES completion:nil];
        return;
    }
    [self queue:paths];
}
@end
