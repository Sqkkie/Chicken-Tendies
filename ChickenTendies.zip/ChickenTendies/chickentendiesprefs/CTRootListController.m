#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import <objc/runtime.h>
#import <notify.h>

static NSString *const D = @"com.chickentendies.prefs";
static NSString *const kStatusNote = @"com.chickentendies/statusChanged";
static NSString *const kCollections = @"com.apple.WallpaperKit.CollectionsPoster";
static NSString *const kPhotos = @"com.apple.PhotosUIPrivate.PhotosPosterProvider";
static const char kInfoTitleKey;
static const char kInfoMsgKey;

static id CTGet(NSString *k, id def) {
    CFPreferencesAppSynchronize((__bridge CFStringRef)D);
    CFPropertyListRef v = CFPreferencesCopyAppValue((__bridge CFStringRef)k, (__bridge CFStringRef)D);
    return v ? CFBridgingRelease(v) : def;
}
static void CTSet(NSString *k, id v) {
    CFPreferencesSetAppValue((__bridge CFStringRef)k, (__bridge CFPropertyListRef)v, (__bridge CFStringRef)D);
    CFPreferencesAppSynchronize((__bridge CFStringRef)D);
}
static void CTPost(NSString *n) { notify_post([[@"com.chickentendies/" stringByAppendingString:n] UTF8String]); }

@interface CTRootListController : PSListController <UIDocumentPickerDelegate>
@end

static void CTStatusCB(CFNotificationCenterRef c, void *obs, CFStringRef n, const void *o, CFDictionaryRef u) {
    CTRootListController *vc = (__bridge CTRootListController *)obs;
    dispatch_async(dispatch_get_main_queue(), ^{ [vc reloadSpecifiers]; });
}

@implementation CTRootListController

- (NSUInteger)pendingCount {
    NSUInteger n = 0;
    for (NSDictionary *q in CTGet(@"queue", @[]))
        if ([q[@"status"] isEqual:@"Pending"]) n++;
    return n;
}
- (void)updateApplyButton {
    self.navigationItem.rightBarButtonItem.enabled = ([self pendingCount] > 0);
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Apply"
        style:UIBarButtonItemStyleDone target:self action:@selector(applyQueue)];
    [self updateApplyButton];
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), (__bridge const void *)self, CTStatusCB,
        (__bridge CFStringRef)kStatusNote, NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
    CTPost(@"scan");
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    CFNotificationCenterRemoveEveryObserver(CFNotificationCenterGetDarwinNotifyCenter(), (__bridge const void *)self);
}

#pragma mark info (i) buttons

- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    UITableViewCell *cell = [super tableView:tv cellForRowAtIndexPath:ip];
    [[cell.contentView viewWithTag:9001] removeFromSuperview];
    id spec = nil;
    @try { spec = [cell valueForKey:@"specifier"]; } @catch (NSException *e) {}
    NSString *info = [spec isKindOfClass:[PSSpecifier class]] ? [(PSSpecifier *)spec propertyForKey:@"ctInfo"] : nil;
    if (info.length) {
        UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
        b.tag = 9001;
        [b setImage:[UIImage systemImageNamed:@"info.circle"] forState:UIControlStateNormal];
        b.translatesAutoresizingMaskIntoConstraints = NO;
        objc_setAssociatedObject(b, &kInfoTitleKey, [(PSSpecifier *)spec name] ?: @"Info", OBJC_ASSOCIATION_COPY_NONATOMIC);
        objc_setAssociatedObject(b, &kInfoMsgKey, info, OBJC_ASSOCIATION_COPY_NONATOMIC);
        [b addTarget:self action:@selector(showInfo:) forControlEvents:UIControlEventTouchUpInside];
        [cell.contentView addSubview:b];
        [NSLayoutConstraint activateConstraints:@[
            [b.trailingAnchor constraintEqualToAnchor:cell.contentView.trailingAnchor constant:-6],
            [b.centerYAnchor constraintEqualToAnchor:cell.contentView.centerYAnchor],
            [b.widthAnchor constraintEqualToConstant:32],
            [b.heightAnchor constraintEqualToConstant:32]]];
    }
    return cell;
}
- (void)showInfo:(UIButton *)b {
    UIAlertController *a = [UIAlertController alertControllerWithTitle:objc_getAssociatedObject(b, &kInfoTitleKey)
        message:objc_getAssociatedObject(b, &kInfoMsgKey) preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:a animated:YES completion:nil];
}

#pragma mark specifier helpers

- (PSSpecifier *)group:(NSString *)name footer:(NSString *)footer {
    PSSpecifier *g = [PSSpecifier groupSpecifierWithName:name];
    if (footer) [g setProperty:footer forKey:@"footerText"];
    return g;
}
- (PSSpecifier *)toggle:(NSString *)name key:(NSString *)key def:(BOOL)def info:(NSString *)info {
    PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:name target:self
        set:@selector(setPreferenceValue:specifier:) get:@selector(readPreferenceValue:)
        detail:nil cell:PSSwitchCell edit:nil];
    [s setProperty:D forKey:@"defaults"];
    [s setProperty:key forKey:@"key"];
    [s setProperty:@(def) forKey:@"default"];
    [s setProperty:info forKey:@"ctInfo"];
    return s;
}
- (PSSpecifier *)button:(NSString *)name action:(SEL)sel info:(NSString *)info {
    PSSpecifier *s = [PSSpecifier preferenceSpecifierNamed:name target:self set:nil get:nil
        detail:nil cell:PSButtonCell edit:nil];
    s.buttonAction = sel;
    [s setProperty:info forKey:@"ctInfo"];
    return s;
}

- (id)queueValue:(PSSpecifier *)spec { return [spec propertyForKey:@"ctValue"]; }

- (NSArray *)specifiers {
    if (_specifiers) return _specifiers;
    NSMutableArray *s = [NSMutableArray array];
    NSString *status = CTGet(@"status", @"Idle.");
    NSString *defExt = CTGet(@"targetExtension", kCollections);
    NSString *extName = [defExt isEqualToString:kPhotos] ? @"Photos" : @"Collections";

    [s addObject:[self group:@"Chicken Tendies" footer:status]];
    [s addObject:[self toggle:@"Enabled" key:@"enabled" def:YES
        info:@"Master switch. When off, the tweak ignores every import, apply and restore request."]];

    // Import
    [s addObject:[self group:@"Import" footer:@"Pick .tendies files from the Files app, or drop them into the inbox folder below and tap Import All."]];
    [s addObject:[self button:@"Import .tendies from Files…" action:@selector(pickFiles)
        info:@"Opens the Files app so you can pick one or more .tendies wallpaper files. They are unpacked into PosterBoard and added to the Queue below. Nothing shows up in the Lock Screen editor until you tap Apply."]];
    [s addObject:[self button:@"Import All From Inbox" action:@selector(importInbox)
        info:@"Imports every .tendies file that is currently sitting in the Inbox folder."]];

    // Queue
    NSArray *queue = CTGet(@"queue", @[]);
    NSString *cur = ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) ? @"iPad" : @"iPhone";
    [s addObject:[self group:@"Queue" footer:(queue.count
        ? @"Wallpapers you've imported. Tap Apply (top right) to restart PosterBoard so pending ones appear in the Lock Screen editor."
        : @"Nothing imported yet. Imported wallpapers are listed here.")]];
    for (NSDictionary *q in queue) {
        NSString *val = q[@"status"] ?: @"Pending";
        NSString *dev = q[@"device"];
        if (dev.length && ![dev isEqualToString:@"?"] && ![dev isEqualToString:cur])
            val = [val stringByAppendingFormat:@" · made for %@", dev];
        PSSpecifier *r = [PSSpecifier preferenceSpecifierNamed:(q[@"name"] ?: @"Wallpaper") target:self
            set:nil get:@selector(queueValue:) detail:nil cell:PSTitleValueCell edit:nil];
        [r setProperty:val forKey:@"ctValue"];
        [r setProperty:@"A wallpaper you imported. Pending = copied into PosterBoard but not applied yet. Applied = PosterBoard was restarted. “made for iPad/iPhone” just means the file is sized for a different device than this one. Some of those still work, so treat it as a hint, not an error." forKey:@"ctInfo"];
        [s addObject:r];
    }
    if (queue.count) {
        [s addObject:[self button:@"Clear Queue" action:@selector(clearQueue)
            info:@"Removes the list above. It does not delete anything from PosterBoard — use Restore Latest Backup for that."]];
    }

    // Installed list (what PosterBoard's store really contains)
    NSArray *inst = CTGet(@"installed", @[]);
    [s addObject:[self group:@"Installed in Collections" footer:CTGet(@"storeInfo", @"Tap Refresh to scan PosterBoard's store.")]];
    NSUInteger shown = 0;
    for (NSDictionary *r in inst) {
        if (shown++ >= 60) break;
        BOOL ours = [r[@"ours"] boolValue];
        PSSpecifier *row = [PSSpecifier preferenceSpecifierNamed:(r[@"name"] ?: @"Wallpaper") target:self
            set:nil get:@selector(queueValue:) detail:nil cell:PSTitleValueCell edit:nil];
        [row setProperty:[NSString stringWithFormat:@"%@ID %@", ours ? @"imported · " : @"", r[@"id"]] forKey:@"ctValue"];
        [row setProperty:@"A wallpaper currently inside PosterBoard's Collections folder, read straight from disk. “imported” = added by Chicken Tendies. The rest are Apple's built-in wallpapers. If your import isn't here, it didn't land in the store PosterBoard reads." forKey:@"ctInfo"];
        [s addObject:row];
    }

    // Inbox contents
    NSArray *files = CTGet(@"inbox", @[]);
    NSString *inboxDir = CTGet(@"inboxDir", @"/var/mobile/Documents/ChickenTendies");
    [s addObject:[self group:@"Inbox" footer:(files.count ? [NSString stringWithFormat:@"Folder: %@", inboxDir]
                                                          : [NSString stringWithFormat:@"No .tendies files in %@", inboxDir])]];
    for (NSString *f in files) {
        PSSpecifier *b = [self button:[@"Import " stringByAppendingString:f] action:@selector(importOne:)
            info:@"Imports just this one file from the Inbox folder into PosterBoard and adds it to the Queue."];
        [b setProperty:f forKey:@"file"];
        [s addObject:b];
    }
    [s addObject:[self button:@"Refresh Inbox & Installed List" action:@selector(refreshInbox)
        info:@"Rescans the Inbox folder for new .tendies files and re-reads what is currently installed in PosterBoard's Collections folder."]];

    // Options
    [s addObject:[self group:@"Options" footer:nil]];
    [s addObject:[self toggle:@"Apply Automatically After Import" key:@"autoApply" def:NO
        info:@"When on, PosterBoard is restarted right after an import, so you don't have to tap Apply. When off, imported wallpapers wait in the Queue until you tap Apply."]];
    [s addObject:[self toggle:@"Respring on Apply" key:@"respringOnApply" def:NO
        info:@"Also respring SpringBoard when applying. Turn this on if wallpapers don't show up after just restarting PosterBoard."]];
    [s addObject:[self toggle:@"Randomize Wallpaper IDs" key:@"randomizeIDs" def:YES
        info:@"Gives every imported wallpaper a new random ID and folder name, like Nugget does. Without this, a wallpaper that reuses a built-in ID (for example a copy of the stock iOS 16 wallpaper, ID 7400) is treated as the built-in one and no new entry appears in Collections. Leave this on."]];
    [s addObject:[self toggle:@"Back Up Before Importing" key:@"backup" def:YES
        info:@"Saves a copy of anything an import would overwrite, so “Restore Latest Backup” can undo the most recent import."]];
    [s addObject:[self toggle:@"Delete .tendies After Import" key:@"deleteAfter" def:NO
        info:@"Deletes the .tendies file after it has been imported successfully (only the copy that was imported)."]];
    [s addObject:[self toggle:@"Auto-Import Inbox After Respring" key:@"autoImport" def:NO
        info:@"After each respring, automatically imports any new .tendies files found in the Inbox folder."]];

    [s addObject:[self button:[@"Default Target Extension: " stringByAppendingString:extName] action:@selector(chooseTarget:)
        info:@"Where wallpapers are placed when a .tendies file doesn't say. Collections = the main wallpaper gallery (what most .tendies files use). Photos = the Suggested Photos poster."]];

    PSSpecifier *path = [PSSpecifier preferenceSpecifierNamed:@"Inbox Folder" target:self
        set:@selector(setPreferenceValue:specifier:) get:@selector(readPreferenceValue:)
        detail:nil cell:PSEditTextCell edit:nil];
    [path setProperty:D forKey:@"defaults"];
    [path setProperty:@"inboxPath" forKey:@"key"];
    [path setProperty:@"/var/mobile/Documents/ChickenTendies" forKey:@"default"];
    [path setProperty:@YES forKey:@"noAutoCorrect"];
    [path setProperty:@"The folder Import All and auto-import read .tendies files from." forKey:@"ctInfo"];
    [s addObject:path];
    [s addObject:[self group:nil footer:@"Used for 'Import All' and auto-import. The default target is only a fallback when a .tendies file doesn't specify an extension."]];

    // Maintenance
    [s addObject:[self group:@"Maintenance" footer:@"Restore undoes the most recent import (needs 'Back Up Before Importing' on)."]];
    [s addObject:[self button:@"Restore Latest Backup" action:@selector(restore)
        info:@"Reverts the most recent import using the backup taken before it. Only works if “Back Up Before Importing” was on."]];
    [s addObject:[self button:@"Restart PosterBoard" action:@selector(restartPoster)
        info:@"Restarts only the PosterBoard process (the Lock Screen wallpaper service). Quicker than a respring."]];
    [s addObject:[self button:@"Respring" action:@selector(respring)
        info:@"Restarts SpringBoard (the home screen). Does not reboot your phone."]];

    _specifiers = s;
    [self updateApplyButton];
    return s;
}

#pragma mark actions

- (void)queue:(NSArray *)paths {
    CTSet(@"pending", paths);
    CTPost(@"importPending");
}
- (void)importOne:(PSSpecifier *)spec {
    NSString *f = [spec propertyForKey:@"file"];
    NSString *dir = CTGet(@"inboxDir", @"/var/mobile/Documents/ChickenTendies");
    [self queue:@[[dir stringByAppendingPathComponent:f]]];
}
- (void)importInbox  { CTPost(@"importInbox"); }
- (void)refreshInbox { CTPost(@"scan"); }
- (void)restartPoster { CTPost(@"restartPoster"); }

- (void)confirm:(NSString *)title msg:(NSString *)msg ok:(void (^)(void))ok {
    UIAlertController *a = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [a addAction:[UIAlertAction actionWithTitle:@"Continue" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *x) { ok(); }]];
    [self presentViewController:a animated:YES completion:nil];
}
- (void)restore { [self confirm:@"Restore latest backup?" msg:@"This reverts the most recent import." ok:^{ CTPost(@"restore"); }]; }
- (void)respring { [self confirm:@"Respring?" msg:nil ok:^{ CTPost(@"restartSpringBoard"); }]; }

- (void)applyQueue {
    [self confirm:@"Apply imported wallpapers?"
              msg:@"This restarts PosterBoard (and respring if that option is on) so the pending wallpapers show up in the Lock Screen editor."
               ok:^{ CTPost(@"apply"); }];
}
- (void)clearQueue {
    CTSet(@"queue", @[]);
    [self reloadSpecifiers];
}

- (void)chooseTarget:(PSSpecifier *)spec {
    UIAlertController *a = [UIAlertController alertControllerWithTitle:@"Default Target Extension"
        message:@"Where imported wallpapers go when the file doesn't specify one."
        preferredStyle:UIAlertControllerStyleActionSheet];
    NSArray *names = @[@"Collections", @"Photos"];
    NSArray *ids = @[kCollections, kPhotos];
    for (NSUInteger i = 0; i < names.count; i++) {
        NSString *ident = ids[i];
        [a addAction:[UIAlertAction actionWithTitle:names[i] style:UIAlertActionStyleDefault handler:^(UIAlertAction *x) {
            CTSet(@"targetExtension", ident);
            [self reloadSpecifiers];
        }]];
    }
    [a addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    a.popoverPresentationController.sourceView = self.view;
    a.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 1, 1);
    [self presentViewController:a animated:YES completion:nil];
}

- (void)pickFiles {
    UIDocumentPickerViewController *p = [[UIDocumentPickerViewController alloc]
        initForOpeningContentTypes:@[UTTypeItem] asCopy:YES];
    p.allowsMultipleSelection = YES;
    p.delegate = self;
    [self presentViewController:p animated:YES completion:nil];
}
- (void)documentPicker:(UIDocumentPickerViewController *)c didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSMutableArray *paths = [NSMutableArray array];
    for (NSURL *u in urls)
        if ([u.pathExtension.lowercaseString isEqualToString:@"tendies"]) [paths addObject:u.path];
    if (!paths.count) {
        UIAlertController *a = [UIAlertController alertControllerWithTitle:@"No .tendies files"
            message:@"The selected files don't have the .tendies extension." preferredStyle:UIAlertControllerStyleAlert];
        [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:a animated:YES completion:nil];
        return;
    }
    [self queue:paths];
}
@end
